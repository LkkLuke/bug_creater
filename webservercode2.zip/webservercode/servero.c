#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <stdlib.h>
#define PORT 1234
#define BACKLOG 1
#define Max 5
#define MAXSIZE 1024

//全域變數
int fdt[Max]={0};
char mes[1024];
char namelist[100][10];
int firsttime=0;
int check=0;
int inviter=0;
int invited=0;
int turn;
char nosuchperson[]="No Such Person!\n";
char invite[]=" 邀請你來一場OX\n";
char inviteno[]=" 拒絕了你的邀請\n";
char certificate[]="hjfjhijdashiafhjdfs";
char system_gas_in[]="System_information:game_strat\n";
char system_gae_in[]="System_information:game_end";
char turnerr[]="Not your turn\n\0";
char fillerr[]="Space already filled\n\0";
char gametable[]="nnnnnnnnn";
char win[]="win\n\0";
char lose[]="lose\n\0";
char pease[]="pease\n\0";
int gamecount=0;
//int store[100];

/**/
int judge(){
	if(gametable[0]==gametable[3]&&gametable[3]==gametable[6]&&gametable[3]!='n'){
		if(gametable[0]=='O') return 1;
		else return 2;
	}
	else if(gametable[1]==gametable[4]&&gametable[4]==gametable[7]&&gametable[1]!='n'){
		if(gametable[1]=='O') return 1;
		else return 2;
	}
	else if(gametable[2]==gametable[5]&&gametable[5]==gametable[8]&&gametable[2]!='n'){
		if(gametable[2]=='O') return 1;
		else return 2;
	}
	else if(gametable[0]==gametable[1]&&gametable[1]==gametable[2]&&gametable[0]!='n'){
		if(gametable[0]=='O') return 1;
		else return 2;
	}
	else if(gametable[3]==gametable[4]&&gametable[4]==gametable[5]&&gametable[3]!='n'){
		if(gametable[3]=='O') return 1;
		else return 2;
	}
	else if(gametable[6]==gametable[7]&&gametable[7]==gametable[8]&&gametable[6]!='n'){
		if(gametable[6]=='O') return 1;
		else return 2;
	}
	else if(gametable[0]==gametable[4]&&gametable[5]==gametable[8]&&gametable[0]!='n'){
		if(gametable[0]=='O') return 1;
		else return 2;
	}
	else if(gametable[2]==gametable[4]&&gametable[4]==gametable[6]&&gametable[2]!='n'){
		if(gametable[2]=='O') return 1;
		else return 2;
	}else if(gamecount>=9){
			return 3;
	}
	return 0;
}
void *pthread_service(void* sfd)
{
    int fd=*(int *)sfd;
    while(1)
    {
        int numbytes;
        int i;
		memset(mes,'\0',1024);
        numbytes=recv(fd,mes,MAXSIZE,0);
        if(numbytes<=0){
            for(i=0;i<Max;i++){
                if(fd==fdt[i]){
                    fdt[i]=0;
                }
            }
            printf("numbytes=%d\n",numbytes);
            printf("exit! fd=%d\n",fd);
            break;

        }
	if(firsttime==1){
	    printf("checkin\n");
	    for(i=0;i<strlen(mes)-8;i++){
	    	//printf("ccc:%c\n",mes[i]);
		namelist[fd][i]=mes[i];
	    }
	    printf("Name:%s\n",namelist[fd]);
	    firsttime=0;
	}
        printf("receive message from %d,size=%d\n",fd,numbytes);
        SendToClient(fd,mes,numbytes);
        bzero(mes,MAXSIZE);

    }
    close(fd);

}


/**/
int SendToClient(int fd,char* buf,int Size)
{
    int i;
    char *pch=NULL;
    printf("All:%s",buf);
    if(strstr(buf,"AllPeoplein")!=NULL){
    for(i=0;i<Max;i++){
        printf("fdt[%d]=%d\n",i,fdt[i]);
        if((fdt[i]!=0)){
	   /*int j=0;
	   char *pch;
	   pch=strstr(buf,":");
	   int tmplen;
	   tmplen=pch-buf;*/
	   //printf("namelen:%d\n",tmplen);
	   /*for(j=0;j<strlen(namelist[fdt[i]]);j++){
		//buf[j+tmplen+1]=namelist[fdt[i]][j];
	   }*/
	   memset(buf,'\0',1024);
	   strncpy(buf,namelist[fdt[i]],strlen(namelist[fdt[i]]));
	   buf[strlen(namelist[fdt[i]])]='\n';
	   buf[strlen(namelist[fdt[i]])+1]='\0';
	   printf("%s",buf);
           if(fdt[i]!=fd){
	       //strncpy(buf,namelist[fdt[i]],5);
	       //printf("%s",buf);
               send(fd,buf,1024,0);
               printf("send namemessage to %d\n",fd);
	           sleep(0.5);
	   	   }
        }
	
    }
    }
	else if(strstr(buf,"invite")!=NULL){
		inviter=fd;
		check=0;
		int tmplen,j,count=0;
		char name[6];
		char tmp[100]={'\0'};
		pch=strstr(buf,"invite");
		tmplen = pch-buf+7;
		printf("tmplen:%d %c\n",tmplen,buf[tmplen]);
		for(j=tmplen;j<Size-1;j++){
			printf("cg:%c\n",buf[j]);
			name[count]=buf[j];
			count++;
		}
		name[count]='\0';
		printf("fg:%s\n",name);
		for(i=0;i<Max;i++){
        	printf("fdt[%d]=%d\n",i,fdt[i]);
        	if((fdt[i]!=0)&&(fdt[i]!=fd)){
				if(strstr(namelist[fdt[i]],name)!=NULL){
					strcat(tmp,namelist[fd]);
					strcat(tmp,invite);
        	    	send(fdt[i],tmp,100,0);
        	    	printf("send message to %d\n",fdt[i]);
					invited=fdt[i];
					check=1;
				}
        	}
    	}
		if(check==0){
			send(fd,nosuchperson,16,0);
			check=0;
		}
	}
	else if((inviter!=invited)&&(fd==invited)&&((strstr(buf,"accept")!=NULL)||(strstr(buf,"no")!=NULL))){
		printf("ccc\n");
		if(strstr(buf,"accept")!=NULL){
        	    send(inviter,system_gas_in,30,0);
				sleep(0.5);
				send(invited,system_gas_in,30,0);
        	    printf("send game start message to %d %d\n",inviter,invited);
				turn = inviter;
		}else if(strstr(buf,"no")!=NULL){
			char tmp[100]={'\0'};
			printf("nocheckl\n");
			strcat(tmp,namelist[inviter]);
			strcat(tmp,inviteno);
			send(inviter,tmp,100,0);
			printf("send message to %d\n",inviter);
		}
	}else if(strstr(buf,certificate)!=NULL&&('a'<=buf[0]&&buf[0]<='c')&&('0'<=buf[1]&&buf[1]<='2')){
		if(turn==fd){
			int tmpnum=0;
			printf("buf[0]:%c\n",buf[0]);
			if('a'==buf[0]) tmpnum=0;
			else if('b'==buf[0]) tmpnum=3;
			else if('c'==buf[0]) tmpnum=6;
			if(buf[1]=='0') tmpnum=tmpnum+0;
			else if(buf[1]=='1') tmpnum=tmpnum+1;
			else if(buf[1]=='2') tmpnum=tmpnum+2;
			printf("tmpnum:%d\n",tmpnum);
			if(fd==inviter){
				if(gametable[tmpnum]=='n'){
					gametable[tmpnum]='O';
					turn=invited;
					char tmp[100]={'\0'};
					strcat(tmp,certificate);
					strcat(tmp,gametable);
					send(fd,tmp,strlen(tmp),0);
					sleep(0.5);
					send(invited,tmp,strlen(tmp),0);
					gamecount=gamecount+1;
					if(judge()>0){
						if(judge()==1){
							char tmp[100]={'\0'};
							strcat(tmp,system_gae_in);
							strcat(tmp,win);
							send(inviter,tmp,strlen(tmp),0);
							sleep(0.5);
							char tmp2[100]={'\0'};
							strcat(tmp2,system_gae_in);
							strcat(tmp2,lose);
							send(invited,tmp2,strlen(tmp2),0);
						}else if(judge()==2){
							char tmp[100]={'\0'};
							strcat(tmp,system_gae_in);
							strcat(tmp,lose);
							send(inviter,tmp,strlen(tmp),0);
							sleep(0.5);
							char tmp2[100]={'\0'};
							strcat(tmp2,system_gae_in);
							strcat(tmp2,win);
							send(invited,tmp2,strlen(tmp2),0);
						}else{
							send(inviter,pease,strlen(pease),0);
							sleep(0.5);
							send(invited,pease,strlen(pease),0);
						}
					}
				}else{
					send(fd,fillerr,strlen(fillerr),0);
				}
			}else{
				if(gametable[tmpnum]=='n'){
					gametable[tmpnum]='X';
					turn=inviter;
					char tmp[100]={'\0'};
					strcat(tmp,certificate);
					strcat(tmp,gametable);
					send(fd,tmp,strlen(tmp),0);
					sleep(0.5);
					send(inviter,tmp,strlen(tmp),0);
					gamecount=gamecount+1;
					if(judge()>0){
						if(judge()==1){
							char tmp[100]={'\0'};
							strcat(tmp,system_gae_in);
							strcat(tmp,win);
							send(inviter,tmp,strlen(tmp),0);
							sleep(0.5);
							char tmp2[100]={'\0'};
							strcat(tmp2,system_gae_in);
							strcat(tmp2,lose);
							send(invited,tmp2,strlen(tmp2),0);
						}else if(judge()==2){
							char tmp[100]={'\0'};
							strcat(tmp,system_gae_in);
							strcat(tmp,lose);
							send(inviter,tmp,strlen(tmp),0);
							sleep(0.5);
							char tmp2[100]={'\0'};
							strcat(tmp2,system_gae_in);
							strcat(tmp2,win);
							send(invited,tmp2,strlen(tmp2),0);
						}else{
							send(inviter,pease,strlen(pease),0);
							sleep(0.5);
							send(invited,pease,strlen(pease),0);
						}
					}
				}else{
					send(fd,fillerr,strlen(fillerr),0);
				}
			}
		}else{
			send(fd,turnerr,strlen(turnerr),0);
		}
	}
    else{ 
    for(i=0;i<Max;i++){
        printf("fdt[%d]=%d\n",i,fdt[i]);
        if((fdt[i]!=0)&&(fdt[i]!=fd)){
            send(fdt[i],buf,Size,0);
            printf("send message to %d\n",fdt[i]);
        }
    }
    }
	memset(buf,'\0',strlen(buf));
    return 0;


}

int  main()
{


    int listenfd, connectfd;
    struct sockaddr_in server;
    struct sockaddr_in client;
    int sin_size;
    sin_size=sizeof(struct sockaddr_in);
    int number=0;
    int fd;


    if ((listenfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("Creating socket failed.");
        exit(1);
    }


    int opt = SO_REUSEADDR;
    setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    bzero(&server,sizeof(server));


    server.sin_family=AF_INET;
    server.sin_port=htons(PORT);
    server.sin_addr.s_addr = htonl (INADDR_ANY);


    if (bind(listenfd, (struct sockaddr *)&server, sizeof(struct sockaddr)) == -1) {
    perror("Bind error.");
    exit(1);
    }


    if(listen(listenfd,BACKLOG) == -1){
    perror("listen() error\n");
    exit(1);
    }
    printf("Waiting for client....\n");


    while(1)
    {

        if ((fd = accept(listenfd,(struct sockaddr *)&client,&sin_size))==-1) {
        perror("accept() error\n");
        exit(1);

        }

        if(number>=Max){
            printf("no more client is allowed\n");
            close(fd);
        }

        int i,j;
	char tmp[5];
	char *pch;
        for(i=0;i<Max;i++){
            if(fdt[i]==0){
                fdt[i]=fd;
				firsttime = 1;
                break;
            }

        }



        pthread_t tid;
        pthread_create(&tid,NULL,(void*)pthread_service,&fd);

        number=number+1;


    }


    close(listenfd);
    }

