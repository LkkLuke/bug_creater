#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include<string.h>
#define PORT 1234
#define MAXDATASIZE 100

    char sendbuf[1024];
    char recvbuf[1024];
    char name[100];
    int fd;
	char certificate[]="hjfjhijdashiafhjdfs";//19
	char system_gas_in[]="System_information:game_strat\n";
	char system_gae_in[]="System_information:game_end";
	char gametable[] = "nnnnnnnnn";
	int g_s=0;

    void pthread_recv(void* ptr)
{
    while(1){
    	if ((recv(fd,recvbuf,MAXDATASIZE,0)) == -1){
        	printf("recv() error\n");
        	exit(1);
        	}
		if(strstr(recvbuf,system_gas_in)!=NULL){
			printf("OX Game start\n");
			int i=0;
			printf("\n 0 1 2\n");
			for(i=1;i<10;i++){
				if(i==1)
					printf("a");
				if(i==4)
					printf("\nb");
				if(i==7)
					printf("\nc");
				printf("%c ",gametable[i-1]);
			}
			printf("\n");
			g_s=1;
			memset(recvbuf,0,sizeof(recvbuf));
		}else if(strstr(recvbuf,certificate)!=NULL){
			int i=0;
			printf("\n 0 1 2\n");
			for(i=0;i<10;i++){
				gametable[i]=recvbuf[i+19];
			}
			for(i=1;i<10;i++){
				if(i==1)
					printf("a");
				if(i==4)
					printf("\nb");
				if(i==7)
					printf("\nc");
				printf("%c ",gametable[i-1]);
			}
			printf("\n");
		}else if(strstr(recvbuf,system_gae_in)!=NULL){
			if(strstr(recvbuf,"win")!=NULL){
				printf("You Win!\n");
			}else{
				printf("You Lose!\n");
			}
			g_s=0;
			memset(gametable,'n',9);
		}else{
    		printf("%s",recvbuf);
    		memset(recvbuf,0,sizeof(recvbuf));
		}
    }
}



    int main(int argc, char *argv[])
    {
    int  numbytes;
    char buf[MAXDATASIZE];
    struct hostent *he;
    struct sockaddr_in server;


    if (argc !=2) {         printf("Usage: %s <IP Address>\n",argv[0]);
    exit(1);
    }


    if ((he=gethostbyname(argv[1]))==NULL){
    printf("gethostbyname() error\n");
    exit(1);
    }

    if ((fd=socket(AF_INET, SOCK_STREAM, 0))==-1){
    printf("socket() error\n");
    exit(1);
    }

    bzero(&server,sizeof(server));

    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr = *((struct in_addr *)he->h_addr);
    if(connect(fd, (struct sockaddr *)&server,sizeof(struct sockaddr))==-1){
    printf("connect() error\n");
    exit(1);
    }

    printf("connect success\n");
    char str[]="Checkin\n";
    printf("請輸入暱稱：");
    fgets(name,sizeof(name),stdin);
    send(fd,name,(strlen(name)-1),0);
    send(fd,str,(strlen(str)),0);


    pthread_t tid;
    pthread_create(&tid,NULL,pthread_recv,NULL);

    while(1)
    {
        memset(sendbuf,0,sizeof(sendbuf));
        fgets(sendbuf,sizeof(sendbuf),stdin);
		//printf("fw:%c\n",sendbuf[1]); 
		//printf("len%d\n",strlen(sendbuf));
	if((g_s==1)&&(strlen(sendbuf)<=3)&&('a'<=sendbuf[0]&&sendbuf[0]<='c')&&('0'<=sendbuf[1]&&sendbuf[1]<='2')){
			strcat(sendbuf,certificate);
			//printf("fw:%c\n",sendbuf[1]); = 0
			//printf("len%d\n",strlen(sendbuf));
			send(fd,sendbuf,(strlen(sendbuf)),0);
		}
        else if(strstr(sendbuf,"exit")!=NULL){
            memset(sendbuf,0,sizeof(sendbuf));
            printf("一切都結束了\n");
            send(fd,sendbuf,(strlen(sendbuf)),0);
            break;
        }else{
        	send(fd,name,(strlen(name)-1),0);
        	send(fd,":",1,0);

        	send(fd,sendbuf,(strlen(sendbuf)),0);
		}


    }
//  sprintf("")
//  if ((numbytes=recv(fd,buf,MAXDATASIZE,0)) == -1){
 // printf("recv() error\n");
 // exit(1);
 // }

    close(fd);
 }
